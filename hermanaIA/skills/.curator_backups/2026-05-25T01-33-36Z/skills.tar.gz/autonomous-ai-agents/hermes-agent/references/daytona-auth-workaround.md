# Daytona Authentication Error Workaround

## Error Encountered
`DaytonaAuthenticationError: Failed to create sandbox: Invalid credentials`
when using `terminal` or `read_file` tools.

## Context
- Occurred in WSL environment with Hermes Agent configured to use `terminal.backend: daytona`.
- Even after changing `terminal.backend` to `local` in `~/.hermes/config.yaml`, the error persisted until the agent was restarted.

## Workflow Used to Diagnose and Work Around
1. **Verified config change**: Used `mcp_filesystem_ubuntu_read_file` to read `/home/amu/.hermes/config.yaml` and confirmed `backend: local` was set.
2. **Checked tool availability**: Ran `hermes tools list` (via web search and terminal attempts) to see available toolsets.
3. **Used alternative tools**: When `terminal` failed, used:
   - `web_search` and `web_extract` for information gathering.
   - `mcp_filesystem_ubuntu_*` commands (e.g., `mcp_filesystem_ubuntu_read_file`, `mcp_filesystem_ubuntu_list_directory`) for file operations.
   - `session_search` for retrieving past conversation content.
4. **Confirmed need for restart**: After verifying the config change, concluded that a restart of the Hermes agent (or at least a session reset via `/reset`) is required for the `terminal.backend` change to take effect.

## Key Takeaways
- Config changes to `terminal.backend` require a fresh agent session (via `/reset` in chat or exiting and relaunching the CLI) to take effect.
- While the Daytona backend is unavailable due to missing credentials, the MCP filesystem tools provide a reliable alternative for file system access within the allowed directory (`/home/amu`).
- For web-related tasks, `web_search` and `web_extract` remain functional regardless of terminal backend status.

## When to Use This Workflow
- If you encounter `DaytonaAuthenticationError` and cannot resolve credentials immediately.
- As a temporary measure while investigating or fixing the Daytona API key/configuration.
- To maintain productivity for file and web tasks without waiting for sandbox resolution.
