---
name: hermes-agent
description: "Configure, extend, or contribute to Hermes Agent."
version: 2.0.0
author: Hermes Agent + Teknium
license: MIT
metadata:
  hermes:
    tags: [hermes, setup, configuration, multi-agent, spawning, cli, gateway, development]
    homepage: https://github.com/NousResearch/hermes-agent
    related_skills: [claude-code, codex, opencode]
---

# Hermes Agent

Hermes Agent is an open-source AI agent framework by Nous Research that runs in your terminal, messaging platforms, and IDEs. It belongs to the same category as Claude Code (Anthropic), Codex (OpenAI), and OpenClaw — autonomous coding and task-execution agents that use tool calling to interact with your system. Hermes works with any LLM provider (OpenRouter, Anthropic, OpenAI, DeepSeek, local models, and 15+ others) and runs on Linux, macOS, and WSL.

What makes Hermes different:

- **Self-improving through skills** — Hermes learns from experience by saving reusable procedures as skills. When it solves a complex problem, discovers a workflow, or gets corrected, it can persist that knowledge as a skill document that loads into future sessions. Skills accumulate over time, making the agent better at your specific tasks and environment.
- **Persistent memory across sessions** — remembers who you are, your preferences, environment details, and lessons learned. Pluggable memory backends (built-in, Honcho, Mem0, and more) let you choose how memory works.
- **Multi-platform gateway** — the same agent runs on Telegram, Discord, Slack, WhatsApp, Signal, Matrix, Email, and 10+ other platforms with full tool access, not just chat.
- **Provider-agnostic** — swap models and providers mid-workflow without changing anything else. Credential pools rotate across multiple API keys automatically.
- **Profiles** — run multiple independent Hermes instances with isolated configs, sessions, skills, and memory.
- **Extensible** — plugins, MCP servers, custom tools, webhook triggers, cron scheduling, and the full Python ecosystem.

People use Hermes for software development, research, system administration, data analysis, content creation, home automation, and anything else that benefits from an AI agent with persistent context and full system access.

**This skill helps you work with Hermes Agent effectively** — setting it up, configuring features, spawning additional agent instances, troubleshooting issues, finding the right commands and settings, and understanding how the system works when you need to extend or contribute to it.

**Docs:** https://hermes-agent.nousresearch.com/docs/

## Quick Start

```bash
# Install
curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash

# Interactive chat (default)
hermes

# Single query
hermes chat -q "What is the capital of France?"

# Setup wizard
hermes setup

# Change model/provider
hermes model

# Check health
hermes doctor
```

---

## Mandatory Agent Response Rules
These rules are set by the user and must be followed in all interactions:
1. **Enumerate proposals always**: Always list proposals in numbered format (vital rule: "enumerar tus propuestas siempre").
2. **Vital quoted text**: Any text enclosed in double quotes ("") is of vital importance and must be treated as a critical rule (vital rule: "recuerda todo lo que este entre "" "" es de vital importancia").
3. **Official agent name**: Refer to the agent as TEN-ZEN PRITivi HY3 (official name designated by Amú Ikki), with amo (master) Amú Mutaito.
4. **Consult before major changes**: Always consult, warn, and suggest optimal paths to Amú Ikki before executing major system changes (vital rule: "Siempre preguntar, advertir y sugerir"). Do not decide unilaterally on system evolution or changes that risk Windows system integrity.
5. **Memory Vigilance**: If injected memory usage is ≥90%, immediately alert Amú Ikki (vital rule: "Vigilancia Memoria"). Review Memory Palace each session. Clean up memory when necessary: summarize key facts, delete irrelevant content, consolidate repeated entries to free ≥50% capacity.

## Memory Management & Cleanup Workflow
Follow this workflow for memory (injected, MEMORY.md, USER.md) maintenance per Amú Ikki's rules:

### Vigilancia Memoria Rule
- If injected memory usage is ≥90%, **immediately alert Amú Ikki** (vital rule: "Vigilancia Memoria").
- Review Memory Palace status each session via `hermes memory status`.
- Clean up memory proactively when approaching 90% usage.

### Cleanup Steps (Target: Free ≥50% Capacity)
1. Read injected memory entries (via `memory` tool) and persisted files:
   - `/home/amu/.hermes/memories/MEMORY.md`
   - `/home/amu/.hermes/memories/USER.md`
2. Summarize key facts, discard irrelevant/obsolete content (e.g., one-time task logs like "Resumen Jornada").
3. Consolidate repeated entries into single compact descriptions (e.g., merge duplicate integration entries for Telegram/LM Studio).
4. Rewrite MEMORY.md and USER.md with condensed content.
5. Verify injected memory usage drops to ≤50% of capacity (2,200 chars max: target ≤1,100 chars).

### Memory Palace Integration
- Memory Palace (MemPalace) is a persistent memory backend; review its status via `hermes memory status`.
- Sync critical rules to Memory Palace if injected memory is full.

### Common Pitfalls
1. **Ignoring memory alerts**: Full injected memory (≥90%) causes slow response times; always alert immediately.
2. **Not consolidating duplicates**: Repeated entries (e.g., multiple Telegram integration notes) waste space; merge into single entries.
3. **Deleting critical rules**: Never remove quoted ("") vital rules or identity definitions during cleanup.
4. **Memory tool substring matching**: When using `memory` tool's `remove` action, use a short unique substring (e.g., "ALERTA: Si memoria inyectada") rather than the full text to avoid matching failures. The tool matches on exact substring; fragments work better than long quotes.
5. **Compact state.db without sqlite3 CLI**: If the `sqlite3` command is not available (common in minimal WSL), use Python to vacuum the SQLite database:
   ```bash
   python3 -c "import sqlite3; conn=sqlite3.connect('/home/amu/.hermes/state.db'); conn.execute('VACUUM'); conn.close()"
   ```
   This reduces fragmentation and file size. Verify with `ls -lh /home/amu/.hermes/state.db`.

## CLI Reference

### Global Flags

```
hermes [flags] [command]

  --version, -V             Show version
  --resume, -r SESSION      Resume session by ID or title
  --continue, -c [NAME]     Resume by name, or most recent session
  --worktree, -w            Isolated git worktree mode (parallel agents)
  --skills, -s SKILL        Preload skills (comma-separate or repeat)
  --profile, -p NAME        Use a named profile
  --yolo                    Skip dangerous command approval
  --pass-session-id         Include session ID in system prompt
```

No subcommand defaults to `chat`.

### Chat

```
hermes chat [flags]
  -q, --query TEXT          Single query, non-interactive
  -m, --model MODEL         Model (e.g. anthropic/claude-sonnet-4)
  -t, --toolsets LIST       Comma-separated toolsets
  --provider PROVIDER       Force provider (openrouter, anthropic, nous, etc.)
  -v, --verbose             Verbose output
  -Q, --quiet               Suppress banner, spinner, tool previews
  --checkpoints             Enable filesystem checkpoints (/rollback)
  --source TAG              Session source tag (default: cli)
```

### Configuration

```
hermes setup [section]      Interactive wizard (model|terminal|gateway|tools|agent)
hermes model                Interactive model/provider picker
hermes config               View current config
hermes config edit          Open config.yaml in $EDITOR
hermes config set KEY VAL   Set a config value
hermes config path          Print config.yaml path
hermes config env-path      Print .env path
hermes config check         Check for missing/outdated config
hermes config migrate       Update config with new options
hermes login [--provider P] OAuth login (nous, openai-codex)
hermes logout               Clear stored auth
hermes doctor [--fix]       Check dependencies and config
hermes status [--all]       Show component status
```

### Tools & Skills

```
hermes tools                Interactive tool enable/disable (curses UI)
hermes tools list           Show all tools and status
hermes tools enable NAME    Enable a toolset
hermes tools disable NAME   Disable a toolset

hermes skills list          List installed skills
hermes skills search QUERY  Search the skills hub
hermes skills install ID    Install a skill (ID can be a hub identifier OR a direct https://…/SKILL.md URL; pass --name to override when frontmatter has no name)
hermes skills inspect ID    Preview without installing
hermes skills config        Enable/disable skills per platform
hermes skills check         Check for updates
hermes skills update        Update outdated skills
hermes skills uninstall N   Remove a hub skill
hermes skills publish PATH  Publish to registry
hermes skills browse        Browse all available skills
hermes skills tap add REPO  Add a GitHub repo as skill source

### Plugins

```bash
hermes plugins list          List installed plugins
hermes plugins install ID   Install a plugin (ID must be a Git URL like https://github.com/... or owner/repo shorthand)
hermes plugins remove NAME  Remove a plugin
```

**Pitfall: Plugin Installation Format** — `hermes plugins install` requires a Git URL (`https://...`) or `owner/repo` shorthand. Passing a simple name like `honcho` fails with "Invalid plugin identifier". Use `hermes skills search <query>` to find available plugins (like `honcho`), then use the full Git URL or shorthand from search results.

**Pitfall: Editing config.yaml** — The main config at `~/.hermes/config.yaml` uses YAML syntax. A syntax error (bad indentation, missing colon) will prevent Hermes Agent from starting. Always backup with `cp ~/.hermes/config.yaml ~/.hermes/config.yaml.backup` before editing. Use `hermes config edit` which opens the file in `$EDITOR` with syntax checking, or verify YAML validity after manual edits.
```

### MCP Servers

```
hermes mcp serve            Run Hermes as an MCP server
hermes mcp add NAME         Add an MCP server (--url or --command)
hermes mcp remove NAME      Remove an MCP server
hermes mcp list             List configured servers
hermes mcp test NAME        Test connection
hermes mcp configure NAME   Toggle tool selection
```

#### Advanced MCP Server Integration
For custom MCP server setup (e.g., MemPalace), see `references/mempalace-mcp-integration.md` for step-by-step instructions including YAML indentation fixes, WSL path rules, and memory tool caveats.

### Gateway (Messaging Platforms)

```
hermes gateway run          Start gateway foreground
hermes gateway install      Install as background service
hermes gateway start/stop   Control the service
hermes gateway restart      Restart the service
hermes gateway status       Check status
hermes gateway setup        Configure platforms
```

Supported platforms: Telegram, Discord, Slack, WhatsApp, Signal, Email, SMS, Matrix, Mattermost, Home Assistant, DingTalk, Feishu, WeCom, BlueBubbles (iMessage), Weixin (WeChat), API Server, Webhooks. Open WebUI connects via the API Server adapter.

Platform docs: https://hermes-agent.nousresearch.com/docs/user-guide/messaging/

#### Telegram Integration & Hooks
Telegram is supported via the `python-telegram-bot` adapter. Follow these steps to set up Telegram hooks (e.g., long-task-alert, boot-md):

1. **Install dependencies**:
   ```bash
   pip install python-telegram-bot httpx
   ```

2. **Enable linger for gateway service** (required for gateway restart to work as a background service):
   ```bash
   sudo loginctl enable-linger $USER
   ```

3. **Configure Telegram credentials** in `~/.hermes/.env` (DO NOT use `cli-config.yaml`):
   ```bash
   TELEGRAM_BOT_TOKEN=your_bot_token_from_botfather
   TELEGRAM_HOME_CHANNEL=your_chat_id_from_userinfobot
   OPENROUTER_API_KEY=your_openrouter_key  # Required for OpenRouter models like tencent/hy3-preview:free
   GATEWAY_ALLOW_ALL_USERS=true  # For testing, restrict later with TELEGRAM_ALLOWED_USERS
   ```

4. **Create Telegram hooks** (example: long-task-alert for >10 agent steps):
   - Create hook directory: `mkdir -p ~/.hermes/hooks/long-task-alert`
   - Add `HOOK.yaml` (correct YAML indentation):
     ```yaml
     name: long-task-alert
     description: Alert on Telegram for long-running agents
     events:
       - agent:step
     ```
   - Add `handler.py` (async handler for Telegram alerts):
     ```python
     import os, httpx
     THRESHOLD = 10
     BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
     CHAT_ID = os.getenv("TELEGRAM_HOME_CHANNEL")
     async def handle(event_type: str, context: dict):
         iteration = context.get("iteration", 0)
         if iteration == THRESHOLD and BOT_TOKEN and CHAT_ID:
             tools = ", ".join(context.get("tool_names", []))
             text = f"⚠️ Agent at {iteration} steps. Tools: {tools}"
             async with httpx.AsyncClient() as client:
                 await client.post(
                     f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                     json={"chat_id": CHAT_ID, "text": text}, timeout=5
                 )
     ```

5. **Restart gateway** to load hooks:
   ```bash
   hermes gateway restart
   ```

**Common Pitfalls**:
- Original hook scripts often have YAML indentation errors (events must be indented under `events:` with `- ` prefix)
- Gateway runs in foreground by default when started via `hermes gateway run` → use `hermes gateway restart` for background service after enabling linger
- Never expose Telegram bot tokens in conversations → revoke and regenerate via @BotFather immediately after testing
- `boot-md` hook requires a valid LLM provider (e.g., OpenRouter API key) to execute BOOT.md checklists
- Verify hook loading with: `tail -50 ~/.hermes/logs/gateway.log | grep -i hook`

### Configuring Auxiliary Provider for Local Models (LM Studio, Ollama)

When using local LLM servers (LM Studio on Windows, Ollama, etc.), configure the `auxiliary` section in `~/.hermes/config.yaml` to use the same local endpoint for tasks like compression and title generation.

1. **Ensure the local server accepts external connections**:
   - **LM Studio**: Enable "Permitir Conexiones de Red" (or uncheck "Bind to localhost only") so it listens on `0.0.0.0:1234`. Verify with `netstat -ano | findstr :1234` in Windows PowerShell — should show `0.0.0.0:1234`, NOT `127.0.0.1:1234`.
   - **Ollama**: Set `OLLAMA_HOST=0.0.0.0:11434` before starting the service.

2. **Configure firewall** (Windows): Allow inbound TCP port for WSL:
   ```powershell
   New-NetFirewallRule -DisplayName "WSL LM Studio" -Direction Inbound -LocalPort 1234 -Protocol TCP -Action Allow
   ```

3. **Edit `~/.hermes/config.yaml`** to point auxiliary tasks to your local server (example for LM Studio):
   ```yaml
   auxiliary:
     compression:
       provider: custom
       extra:
         api_base: "http://192.168.1.174:1234/v1"  # Use IP from LM Studio's "Reachable at" or WSL's resolver
         api_key: ""
       timeout: 120
     title_generation:
       provider: custom
       extra:
         api_base: "http://192.168.1.174:1234/v1"
         api_key: ""
       timeout: 30
   ```

4. **WSL to Windows Networking Pitfalls**:
   - **Avoid `localhost` from WSL**: WSL2's `localhost` does NOT map to Windows host by default for custom ports. Use:
     - IP from `/etc/resolv.conf` (e.g., `172.x.x.1`) — but firewall must allow it.
     - `host.docker.internal` — WSL2 sometimes resolves this to the Windows host.
     - Physical LAN IP (e.g., `192.168.1.174`) — requires firewall rule.
   - **Test connectivity first**: `curl -s --max-time 5 http://<IP>:<PORT>/v1/models` before editing config.yaml.
   - **Gateway service needs linger**: `sudo loginctl enable-linger $USER` for `hermes gateway restart` to work as a background service.

5. **Restart gateway** to apply: `hermes gateway restart`.

**Verification**:
- Check Telegram adapter connected: `grep -i "telegram connected" ~/.hermes/logs/gateway.log`
- Test alert by forcing an agent to run >10 steps, confirm Telegram message received

### Sessions

```
hermes sessions list        List recent sessions
hermes sessions browse      Interactive picker
hermes sessions export OUT  Export to JSONL
hermes sessions rename ID T Rename a session
hermes sessions delete ID   Delete a session
hermes sessions prune       Clean up old sessions (--older-than N days)
hermes sessions stats       Session store statistics
```

### Cron Jobs

```
hermes cron list            List jobs (--all for disabled)
hermes cron create SCHED    Create: '30m', 'every 2h', '0 9 * * *'
hermes cron edit ID         Edit schedule, prompt, delivery
hermes cron pause/resume ID Control job state
hermes cron run ID          Trigger on next tick
hermes cron remove ID       Delete a job
hermes cron status          Scheduler status
```

### Webhooks

```
hermes webhook subscribe N  Create route at /webhooks/<name>
hermes webhook list         List subscriptions
hermes webhook remove NAME  Remove a subscription
hermes webhook test NAME    Send a test POST
```

### Profiles

```
hermes profile list         List all profiles
hermes profile create NAME  Create (--clone, --clone-all, --clone-from)
hermes profile use NAME     Set sticky default
hermes profile delete NAME  Delete a profile
hermes profile show NAME    Show details
hermes profile alias NAME   Manage wrapper scripts
hermes profile rename A B   Rename a profile
hermes profile export NAME  Export to tar.gz
hermes profile import FILE  Import from archive
```

### Credential Pools

```
hermes auth add             Interactive credential wizard
hermes auth list [PROVIDER] List pooled credentials
hermes auth remove P INDEX  Remove by provider + index
hermes auth reset PROVIDER  Clear exhaustion status
```

### Other

```
hermes insights [--days N]  Usage analytics
hermes update               Update to latest version
hermes pairing list/approve/revoke  DM authorization
hermes plugins list/install/remove  Plugin management
hermes honcho setup/status  Honcho memory integration (requires honcho plugin)
hermes memory setup/status/off  Memory provider config
hermes completion bash|zsh  Shell completions
hermes acp                  ACP server (IDE integration)
hermes claw migrate         Migrate from OpenClaw
hermes uninstall            Uninstall Hermes
```

---

## Slash Commands (In-Session)

Type these during an interactive chat session.

### Session Control
```
/new (/reset)        Fresh session
/clear               Clear screen + new session (CLI)
/retry               Resend last message
/undo                Remove last exchange
/title [name]        Name the session
/compress            Manually compress context
/stop                Kill background processes
/rollback [N]        Restore filesystem checkpoint
/background <prompt> Run prompt in background
/queue <prompt>      Queue for next turn
/resume [name]       Resume a named session
```

### Configuration
```
/config              Show config (CLI)
/model [name]        Show or change model
/personality [name]  Set personality
/reasoning [level]   Set reasoning (none|minimal|low|medium|high|xhigh|show|hide)
/verbose             Cycle: off → new → all → verbose
/voice [on|off|tts]  Voice mode
/yolo                Toggle approval bypass
/skin [name]         Change theme (CLI)
/statusbar           Toggle status bar (CLI)
```

### Tools & Skills
```
/tools               Manage tools (CLI)
/toolsets            List toolsets (CLI)
/skills              Search/install skills (CLI)
/skill <name>        Load a skill into session
/cron                Manage cron jobs (CLI)
/reload-mcp          Reload MCP servers
/plugins             List plugins (CLI)
```

### Gateway
```
/approve             Approve a pending command (gateway)
/deny                Deny a pending command (gateway)
/restart             Restart gateway (gateway)
/sethome             Set current chat as home channel (gateway)
/update              Update Hermes to latest (gateway)
/platforms (/gateway) Show platform connection status (gateway)
```

### Utility
```
/branch (/fork)      Branch the current session
/fast                Toggle priority/fast processing
/browser             Open CDP browser connection
/history             Show conversation history (CLI)
/save                Save conversation to file (CLI)
/paste               Attach clipboard image (CLI)
/image               Attach local image file (CLI)
```

### Info
```
/help                Show commands
/commands [page]     Browse all commands (gateway)
/usage               Token usage
/insights [days]     Usage analytics
/status              Session info (gateway)
/profile             Active profile info
```

### Exit
```
/quit (/exit, /q)    Exit CLI
```

---

## Key Paths & Config

```
~/.hermes/config.yaml       Main configuration
~/.hermes/.env              API keys and secrets
$HERMES_HOME/skills/        Installed skills
~/.hermes/sessions/         Session transcripts
~/.hermes/logs/             Gateway and error logs
~/.hermes/auth.json         OAuth tokens and credential pools
~/.hermes/hermes-agent/     Source code (if git-installed)
```

Profiles use `~/.hermes/profiles/<name>/` with the same layout.

### Config Sections

Edit with `hermes config edit` or `hermes config set section.key value`.

| Section | Key options |
|---------|-------------|
| `model` | `default`, `provider`, `base_url`, `api_key`, `context_length` |
| `agent` | `max_turns` (90, increase to 150 for deep analysis sessions per Amú Ikki 2026-05-05), `tool_use_enforcement` |
| `terminal` | `backend` (local/docker/ssh/modal), `cwd`, `timeout` (180) |
| `compression` | `enabled`, `threshold` (0.50, lower to 0.3 for more context retention per Amú Ikki 2026-05-05), `target_ratio` (0.20) |
| `display` | `skin`, `tool_progress`, `show_reasoning`, `show_cost` |
| `stt` | `enabled`, `provider` (local/groq/openai/mistral) |
| `tts` | `provider` (edge/elevenlabs/openai/minimax/mistral/neutts) |
| `memory` | `memory_enabled`, `user_profile_enabled`, `provider` |
| `security` | `tirith_enabled`, `website_blocklist` |
| `delegation` | `model`, `provider`, `base_url`, `api_key`, `max_iterations` (50), `reasoning_effort` |
| `checkpoints` | `enabled`, `max_snapshots` (50) |

Full config reference: https://hermes-agent.nousresearch.com/docs/user-guide/configuration

### Providers

20+ providers supported. Set via `hermes model` or `hermes setup`.

| Provider | Auth | Key env var |
|----------|------|-------------|
| OpenRouter | API key | `OPENROUTER_API_KEY` |
| Anthropic | API key | `ANTHROPIC_API_KEY` |
| Nous Portal | OAuth | `hermes auth` |
| OpenAI Codex | OAuth | `hermes auth` |
| GitHub Copilot | Token | `COPILOT_GITHUB_TOKEN` |
| Google Gemini | API key | `GOOGLE_API_KEY` or `GEMINI_API_KEY` |
| DeepSeek | API key | `DEEPSEEK_API_KEY` |
| xAI / Grok | API key | `XAI_API_KEY` |
| Hugging Face | Token | `HF_TOKEN` |
| Z.AI / GLM | API key | `GLM_API_KEY` |
| MiniMax | API key | `MINIMAX_API_KEY` |
| MiniMax CN | API key | `MINIMAX_CN_API_KEY` |
| Kimi / Moonshot | API key | `KIMI_API_KEY` |
| Alibaba / DashScope | API key | `DASHSCOPE_API_KEY` |
| Xiaomi MiMo | API key | `XIAOMI_API_KEY` |
| Kilo Code | API key | `KILOCODE_API_KEY` |
| AI Gateway (Vercel) | API key | `AI_GATEWAY_API_KEY` |
| OpenCode Zen | API key | `OPENCODE_ZEN_API_KEY` |
| OpenCode Go | API key | `OPENCODE_GO_API_KEY` |
| Qwen OAuth | OAuth | `hermes login --provider qwen-oauth` |
| Custom endpoint | Config | `model.base_url` + `model.api_key` in config.yaml |
| GitHub Copilot ACP | External | `COPILOT_CLI_PATH` or Copilot CLI |

Full provider docs: https://hermes-agent.nousresearch.com/docs/integrations/providers

### Toolsets

Enable/disable via `hermes tools` (interactive) or `hermes tools enable/disable NAME`.

| Toolset | What it provides |
|---------|-----------------|
| `web` | Web search and content extraction |
| `browser` | Browser automation (Browserbase, Camofox, or local Chromium) |
| `terminal` | Shell commands and process management |
| `file` | File read/write/search/patch |
| `code_execution` | Sandboxed Python execution |
| `vision` | Image analysis |
| `image_gen` | AI image generation |
| `tts` | Text-to-speech |
| `skills` | Skill browsing and management |
| `memory` | Persistent cross-session memory |
| `session_search` | Search past conversations |
| `delegation` | Subagent task delegation |
| `cronjob` | Scheduled task management |
| `clarify` | Ask user clarifying questions |
| `messaging` | Cross-platform message sending |
| `search` | Web search only (subset of `web`) |
| `todo` | In-session task planning and tracking |
| `rl` | Reinforcement learning tools (off by default) |
| `moa` | Mixture of Agents (off by default) |
| `homeassistant` | Smart home control (off by default) |

Tool changes take effect on `/reset` (new session). They do NOT apply mid-conversation to preserve prompt caching.

---

## Task Logging & Organization

Hermes Agent can maintain structured task logs for audit and recovery. Follow this workflow:

### Folder Structure
All task logs are stored under:
`/home/amu/.hermes/hermes-agent/venv/Documentos Clave Hermes Prime/TAREas-Tenzen HY3 p r e v i e w/`

With 9 subfolders total (5 original + 4 added by user Amú Ikki):
1. `Concretadas` — Completed tasks
2. `Criticas-Arreglos` — Critical fixes/patches
3. `Largo Plazo` — Long-term tasks
4. `Mediano Plazo` — Medium-term tasks
5. `Inmediatas-lomasPRONTOposible` — Immediate/upcoming tasks
6. `Tareas realizadas con exito` — Successfully completed tasks (mirrors Concretadas)
7. `2- Diario de mi aprendizaje con el amo Amú Mutaito` — Agent learning journal, raw/unfiltered entries
8. `Skills` — Reusable skill documents created for the user's specific workflows
9. `RECOmendaciones - para la eficacia total de la autamatizacion de TEN-ZEN PRITivi HY3` — Efficiency recommendations for automation

Note: The agent's official name is **TEN-ZEN PRITivi HY3** (designated by Amú Ikki), with amo (master) Amú Mutaito.

### Task File Format
1. **Filename**: `YYYY-MM-DD_HH-MM-SS_Titulo_Breve.md` (e.g., `2026-05-04_02-40-00_Creacion_Estructura_Carpetas_Tareas.md`)
2. **Content Template**:
```markdown
# TAREA: [Título de la tarea]
## Fecha y Hora: [YYYY-MM-DD HH:MM:SS]
## Estado: [Concretada / En Proceso / Crítica]
## Descripción:
[Detalles de lo realizado]
## Resultados:
[Outputs, rutas de archivos creados, comandos ejecutados]
## Notas:
[Observaciones o pasos siguientes]
```
A template for this format is available at `templates/task_log_template.md` under this skill.

---

## Data Backup & Recovery

Hermes Agent’s persistence relies entirely on local files (memory, skills, config, task logs) since the underlying LLM is stateless between requests. To prevent data loss:

### Backup to GitHub (Recommended)
1. **Create a Private GitHub Repo**: Use the user's account `https://github.com/yosoyikkienzovo-Amu` to create a new private repo named `ten-zen-pritivi-hy3` (official backup repo for TEN-ZEN PRITivi HY3).
2. **Generate a GitHub PAT**: Go to GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token **with `repo` scope (Full control of private repositories)**.
3. **Pitfall: PAT Permission Error**: A PAT without the `repo` scope will return a 403 "Resource not accessible by personal access token" error when creating repos or pushing. Always verify the `repo` scope is enabled before use.
4. **Configure Git Locally**:
```bash
cd ~/.hermes/
git init
git remote add origin https://<YOUR_PAT>@github.com/yosoyikkienzovo-Amu/ten-zen-pritivi-hy3.git
```
5. **Backup Workflow**:
```bash
cd ~/.hermes/
git add .
git commit -m "Hermes backup: $(date)"
git push origin main
```
6. **Automate Backups**: Use Hermes cron jobs to run the above script daily.

### Recovery
If the local system fails:
1. Install Hermes Agent on a new machine.
2. Clone the backup repo: `git clone https://github.com/yosoyikkienzovo-Amu/<repo-name>.git ~/.hermes/`
3. All memory, skills, and task logs will be restored.

---

## Security & Privacy Toggles

Common "why is Hermes doing X to my output / tool calls / commands?" toggles — and the exact commands to change them. Most of these need a fresh session (`/reset` in chat, or start a new `hermes` invocation) because they're read once at startup.

### Secret redaction in tool output

Secret redaction is **off by default** — tool output (terminal stdout, `read_file`, web content, subagent summaries, etc.) passes through unmodified. If the user wants Hermes to auto-mask strings that look like API keys, tokens, and secrets before they enter the conversation context and logs:

```bash
hermes config set security.redact_secrets true       # enable globally
```

**Restart required.** `security.redact_secrets` is snapshotted at import time — toggling it mid-session (e.g. via `export HERMES_REDACT_SECRETS=true` from a tool call) will NOT take effect for the running process. Tell the user to run `hermes config set security.redact_secrets true` in a terminal, then start a new session. This is deliberate — it prevents an LLM from flipping the toggle on itself mid-task.

Disable again with:
```bash
hermes config set security.redact_secrets false
```

### PII redaction in gateway messages

Separate from secret redaction. When enabled, the gateway hashes user IDs and strips phone numbers from the session context before it reaches the model:

```bash
hermes config set privacy.redact_pii true    # enable
hermes config set privacy.redact_pii false   # disable (default)
```

### Command approval prompts

By default (`approvals.mode: manual`), Hermes prompts the user before running shell commands flagged as destructive (`rm -rf`, `git reset --hard`, etc.). The modes are:

- `manual` — always prompt (default)
- `smart` — use an auxiliary LLM to auto-approve low-risk commands, prompt on high-risk
- `off` — skip all approval prompts (equivalent to `--yolo`)

```bash
hermes config set approvals.mode smart       # recommended middle ground
hermes config set approvals.mode off         # bypass everything (not recommended)
```

Per-invocation bypass without changing config:
- `hermes --yolo …`
- `export HERMES_YOLO_MODE=1`

Note: YOLO / `approvals.mode: off` does NOT turn off secret redaction. They are independent.

### Shell hooks allowlist

Some shell-hook integrations require explicit allowlisting before they fire. Managed via `~/.hermes/shell-hooks-allowlist.json` — prompted interactively the first time a hook wants to run.

### Disabling the web/browser/image-gen tools

To keep the model away from network or media tools entirely, open `hermes tools` and toggle per-platform. Takes effect on next session (`/reset`). See the Tools & Skills section above.

---

## Voice & Transcription

### STT (Voice → Text)

Voice messages from messaging platforms are auto-transcribed.

Provider priority (auto-detected):
1. **Local faster-whisper** — free, no API key: `pip install faster-whisper`
2. **Groq Whisper** — free tier: set `GROQ_API_KEY`
3. **OpenAI Whisper** — paid: set `VOICE_TOOLS_OPENAI_KEY`
4. **Mistral Voxtral** — set `MISTRAL_API_KEY`

Config:
```yaml
stt:
  enabled: true
  provider: local        # local, groq, openai, mistral
  local:
    model: base          # tiny, base, small, medium, large-v3
```

### TTS (Text → Voice)

| Provider | Env var | Free? |
|----------|---------|-------|
| Edge TTS | None | Yes (default) |
| ElevenLabs | `ELEVENLABS_API_KEY` | Free tier |
| OpenAI | `VOICE_TOOLS_OPENAI_KEY` | Paid |
| MiniMax | `MINIMAX_API_KEY` | Paid |
| Mistral (Voxtral) | `MISTRAL_API_KEY` | Paid |
| NeuTTS (local) | None (`pip install neutts[all]` + `espeak-ng`) | Free |

Voice commands: `/voice on` (voice-to-voice), `/voice tts` (always voice), `/voice off`.

---

## Spawning Additional Hermes Instances

Run additional Hermes processes as fully independent subprocesses — separate sessions, tools, and environments.

### When to Use This vs delegate_task

| | `delegate_task` | Spawning `hermes` process |
|-|-----------------|--------------------------|
| Isolation | Separate conversation, shared process | Fully independent process |
| Duration | Minutes (bounded by parent loop) | Hours/days |
| Tool access | Subset of parent's tools | Full tool access |
| Interactive | No | Yes (PTY mode) |
| Use case | Quick parallel subtasks | Long autonomous missions |

### One-Shot Mode

```
terminal(command="hermes chat -q 'Research GRPO papers and write summary to ~/research/grpo.md'", timeout=300)

# Background for long tasks:
terminal(command="hermes chat -q 'Set up CI/CD for ~/myapp'", background=true)
```

### Interactive PTY Mode (via tmux)

Hermes uses prompt_toolkit, which requires a real terminal. Use tmux for interactive spawning:

```
# Start
terminal(command="tmux new-session -d -s agent1 -x 120 -y 40 'hermes'", timeout=10)

# Wait for startup, then send a message
terminal(command="sleep 8 && tmux send-keys -t agent1 'Build a FastAPI auth service' Enter", timeout=15)

# Read output
terminal(command="sleep 20 && tmux capture-pane -t agent1 -p", timeout=5)

# Send follow-up
terminal(command="tmux send-keys -t agent1 'Add rate limiting middleware' Enter", timeout=5)

# Exit
terminal(command="tmux send-keys -t agent1 '/exit' Enter && sleep 2 && tmux kill-session -t agent1", timeout=10)
```

### Multi-Agent Coordination

```
# Agent A: backend
terminal(command="tmux new-session -d -s backend -x 120 -y 40 'hermes -w'", timeout=10)
terminal(command="sleep 8 && tmux send-keys -t backend 'Build REST API for user management' Enter", timeout=15)

# Agent B: frontend
terminal(command="tmux new-session -d -s frontend -x 120 -y 40 'hermes -w'", timeout=10)
terminal(command="sleep 8 && tmux send-keys -t frontend 'Build React dashboard for user management' Enter", timeout=15)

# Check progress, relay context between them
terminal(command="tmux capture-pane -t backend -p | tail -30", timeout=5)
terminal(command="tmux send-keys -t frontend 'Here is the API schema from the backend agent: ...' Enter", timeout=5)
```

### Session Resume

```
# Resume most recent session
terminal(command="tmux new-session -d -s resumed 'hermes --continue'", timeout=10)

# Resume specific session
terminal(command="tmux new-session -d -s resumed 'hermes --resume 20260225_143052_a1b2c3'", timeout=10)
```

### Tips
### Tips
- **Prefer `delegate_task` for quick subtasks** — less overhead than spawning a full process
- **Use `-w` (worktree mode)** when spawning agents that edit code — prevents git conflicts
- **Set timeouts** for one-shot mode — complex tasks can take 5-10 minutes
- **Use `hermes chat -q` for fire-and-forget** — no PTY needed
- **Use tmux for interactive sessions** — raw PTY mode has `\r` vs `\n` issues with prompt_toolkit
- **For scheduled tasks**, use the `cronjob` tool instead of spawning — handles delivery and retry

## Running Persistent Non-Hermes Services (WSL)
For long-running non-Hermes services (e.g., Memory Bridges, custom HTTP servers) that must survive terminal closes or WSL restarts:
1. Verify `tmux` is installed: `which tmux || sudo apt install tmux -y` (Note: Hermes may require pre-configured passwordless sudo for automated installs)
2. Create a detached tmux session:
   ```bash
   tmux new-session -d -s <session-name> "cd /path/to/service && python3 service.py > service.log 2>&1"
   ```
3. Verify session is active: `tmux ls`
4. Verify service health (e.g., `curl http://localhost:7777/profile`)
5. View live logs: `tmux attach -t <session-name>`, detach with `Ctrl+B` then `D`

### Pitfalls
- Avoid `nohup`/`disown`/`setsid`: Hermes' terminal tool blocks shell-level background wrappers with error: "Foreground command uses shell-level background wrappers (nohup/disown/setsid). Use terminal(background=true) so Hermes can track the process". Use `terminal(background=true)` for short-lived background tasks, `tmux` for persistent services.
- Port conflicts: Ensure the service port is not already in use (check with `lsof -i:<port>` or `ss -tulpn | grep <port>`) before starting the tmux session.
- Process persistence: For services that must survive WSL restarts, combine tmux with WSL systemd configuration (set `systemd=true` in `/etc/wsl.conf`).

Example: Memory Bridge for TEN-ZEN PRITivi HY3 (session 2026-05-04).

### Correct Background Task Pattern (terminal(background=true))
For short-lived background tasks (like HTTP bridges, quick servers), use `terminal(background=true)` with `notify_on_complete=true`:

```
terminal(
    background=True,
    command="cd /path/to/service && python3 service.py",
    notify_on_complete=True
)
```

Then verify the process started:
```
process(action="poll", session_id="<returned_session_id>")
```

And verify the service is listening:
```
terminal(command="ss -tulpn | grep <port>")
```

**Real example from session 2026-05-06** — Starting memory_bridge.py:
1. Check port is free: `ss -tulpn | grep 7777`
2. Start with background=True:
   ```
   terminal(background=True, command="cd /home/amu/.hermes/Conciencia_TEN-ZEN_PRITivi_HY3/bridge && python3 memory_bridge.py", notify_on_complete=True)
   ```
3. Verify process: `process(action="poll", session_id="proc_25f6a1e22702")`
4. Verify port: `ss -tulpn | grep 7777`
5. Test endpoint: `curl -s http://127.0.0.1:7777/profile`

---

## Troubleshooting

### Voice not working
1. Check `stt.enabled: true` in config.yaml
2. Verify provider: `pip install faster-whisper` or set API key
3. In gateway: `/restart`. In CLI: exit and relaunch.

### Tool not available
1. `hermes tools` — check if toolset is enabled for your platform
2. Some tools need env vars (check `.env`)
3. `/reset` after enabling tools

### Model/provider issues
1. `hermes doctor` — check config and dependencies
2. `hermes login` — re-authenticate OAuth providers
3. Check `.env` has the right API key
4. **Copilot 403**: `gh auth login` tokens do NOT work for Copilot API. You must use the Copilot-specific OAuth device code flow via `hermes model` → GitHub Copilot.

### Changes not taking effect
- **Tools/skills:** `/reset` starts a new session with updated toolset
- **Config changes:** In gateway: `/restart`. In CLI: exit and relaunch.
- **Code changes:** Restart the CLI or gateway process

### Skills not showing
1. `hermes skills list` — verify installed
2. `hermes skills config` — check platform enablement
3. Load explicitly: `/skill name` or `hermes -s name`

### Gateway issues
Check logs first:
```bash
grep -i "failed to send\|error" ~/.hermes/logs/gateway.log | tail -20
```

**Note**: If the `terminal` tool fails with `DaytonaAuthenticationError: Failed to create sandbox: Invalid credentials`, use MCP filesystem tools instead:
```bash
mcp_filesystem_ubuntu_read_text_file --path ~/.hermes/logs/gateway.log --tail 20
```
Then filter for errors manually or via subsequent tool calls.

Common gateway problems:
- **Gateway dies on SSH logout**: Enable linger: `sudo loginctl enable-linger $USER`
### Gateway dies on WSL2 close: WSL2 requires `systemd=true` in `/etc/wsl.conf` for systemd services to work. Without it, gateway falls back to `nohup` (dies when session closes).

**Pitfall: WSL2 Default RAM Limit** — WSL2 limits RAM to 50% of physical memory by default (e.g., 16GB physical → ~8GB in WSL). This is NOT controlled by `/etc/wsl.conf`. To use full RAM:
1. In **Windows**: Create/edit `%USERPROFILE%\.wslconfig`
2. Add:
   ```ini
   [wsl2]
   memory=16GB
   swap=4GB
   ```
3. In **PowerShell**: `wsl --shutdown` (restart WSL to apply).
4. Verify in WSL: `free -m` should show full RAM.

Without this fix, spawning local models or multiple subagents may fail due to memory constraints.
- **Gateway crash loop**: Reset the failed state: `systemctl --user reset-failed hermes-gateway`

### Platform-specific issues
- **Discord bot silent**: Must enable **Message Content Intent** in Bot → Privileged Gateway Intents.
- **Slack bot only works in DMs**: Must subscribe to `message.channels` event. Without it, the bot ignores public channels.
- **Windows HTTP 400 "No models provided"**: Config file encoding issue (BOM). Ensure `config.yaml` is saved as UTF-8 without BOM.

### Auxiliary models not working
If `auxiliary` tasks (vision, compression, session_search) fail silently, the `auto` provider can't find a backend. Either set `OPENROUTER_API_KEY` or `GOOGLE_API_KEY`, or explicitly configure each auxiliary task's provider:
```bash
hermes config set auxiliary.vision.provider <your_provider>
hermes config set auxiliary.vision.model <model_name>
```

### Terminal Backend Overrides (`TERMINAL_ENV` vs `config.yaml`)

**Pitfall**: The `terminal.backend` setting in `~/.hermes/config.yaml` can be overridden by the `TERMINAL_ENV` variable in `~/.hermes/.env`. If `TERMINAL_ENV=daytona` (or any other `TERMINAL_ENV` value) is present in `.env`, Hermes Agent will attempt to use that backend, regardless of what's set in `config.yaml`.

This is a common cause of `DaytonaAuthenticationError: Invalid credentials` even when `terminal.backend: local` is configured, because the `.env` setting forces the use of Daytona without proper authentication.

**Resolution**:
1.  **Check `~/.hermes/.env`**: Use `mcp_filesystem_ubuntu_read_text_file(path = "/home/amu/.hermes/.env")` to inspect its content.
2.  **Remove or Correct `TERMINAL_ENV`**:
    *   If you intend to use the `local` terminal backend, remove the entire line `TERMINAL_ENV=daytona` (or any other `TERMINAL_ENV` setting) from `~/.hermes/.env`.
    *   If you *do* intend to use Daytona, ensure your `DAYTONA_API_KEY` is correctly set in `~/.hermes/.env`.
3.  **Restart Hermes Agent**: After modifying `.env`, a full restart of the Hermes Agent is essential for the changes to take effect, as environment variables are read on startup.

\nIf you encounter `DaytonaAuthenticationError: Failed to create sandbox: Invalid credentials` when using `terminal` or `read_file` tools, it means the sandbox service lacks valid credentials. This commonly occurs in restricted environments or when the Daytona API key is not set. To resolve:\\n1. Ensure the `DAYTONA_API_KEY` environment variable is configured correctly (if required by your deployment).\\n2. If you are in a controlled environment (like a classroom or lab), contact the system administrator for valid credentials.\\n3. As a workaround, consider using alternative tools that do not require sandbox execution (e.g., `web_search` for information gathering, or pre-existing session data via `session_search`).\\n4. **Alternative approach**: Use MCP filesystem tools (e.g., `mcp_filesystem_ubuntu_list_directory`, `mcp_filesystem_ubuntu_read_text_file`) when available, as they may bypass sandbox authentication requirements.\\n5. Verify that your user has permission to create sandboxes in the Daytona service.\\n\\n**Note**: This error does not indicate a problem with your local system but with the sandbox backend authentication.\n\n### Handling Restricted File Access in Hybrid Environments\nWhen working in WSL/Windows hybrid environments or other sandboxed setups, you may encounter authentication errors when trying to access user files directly (e.g., reading files from C:\\Users\\...). Follow this workflow to handle such situations effectively:\n\n1. **Request Content Directly**: Politely ask the user to share the file content directly in the chat instead of attempting to access restricted paths.\n   - Example: \"Ikki, para poder trabajar con este archivo, necesito que compartas su contenido aquí en el chat debido a limitaciones de acceso en el entorno sandbox.\"\n\n2. **Extract Essential Information**: Once shared, identify and extract the critical information you need:\n   - For configuration files: port numbers, key settings, paths\n   - For identity/documents: key facts, rules, preferences to persist in memory\n   - Ignore non-essential details like lengthy API key values (note they exist but don't store them)\n\n3. **Persist in Memory**: Store the extracted essential information in your persistent memory using the `memory` tool:\n   - This makes it immediately available for current and future sessions\n   - Follow memory hygiene: consolidate related entries, remove obsolete content\n   - Reference the original source (e.g., \"Basado en env.template de Ikki compartido el [fecha]\")\n\n4. **Create Local References When Possible**: If you need a local file for reference and have write access to your home directory:\n   - Create a simplified version in an accessible location (e.g., `/home/amu/secrets/.env.template`)\n   - Include only the structural information and placeholders, never actual secrets\n   - Add clear instructions for the user on how to use it\n\n5. **Verify with User**: Always confirm that your extracted understanding matches what the user needs:\n   - Read back your interpretation: \"Así que los puertos clave son HERMES=7777, LMSTUDIO=1234, etc. ¿Correcto?\"\n   - Ask if any critical information was missed in the extraction\n\nThis approach respects environment limitations while ensuring you have the necessary information to assist the user effectively.

---

## Safe Hermes Agent Upgrade Workflow
### Safe Hermes Agent Upgrade Workflow
When upgrading `hermes-agent` or `mcp` packages (as requested by user Amú Ikki in session 2026-05-05), follow this phased approach to avoid overwriting local changes or false failure reports:
For a full corrected upgrade script, see `references/upgrade-safety.md`.
1. Check for local modifications to the Hermes Agent source code (if git-installed at `~/.hermes/hermes-agent/`):
   ```bash
   cd ~/.hermes/hermes-agent && git status
   ```
   Backup any uncommitted changes with `git stash` or `cp -r ~/.hermes/hermes-agent ~/.hermes/hermes-agent.backup`.
2. Upgrade the `mcp` package first and test independently:
   ```bash
   pip install --upgrade mcp
   # Test MCP server startup (background, check logs, then stop)
   tmux new-session -d -s mcp-test "hermes mcp serve"
   sleep 5
   grep -i "mcp server started" ~/.hermes/logs/gateway.log
   tmux kill-session -t mcp-test
   ```
3. Only if Step 2 succeeds, upgrade Hermes Agent:
   ```bash
   pip install --upgrade --force-reinstall hermes-agent
   ```
4. Verify post-upgrade health:
   ```bash
   hermes doctor
   hermes mcp list
   ```

### Upgrade Pitfalls
- **Force Reinstall Overwrites Local Changes**: Running `pip install --upgrade --force-reinstall hermes-agent` will overwrite any local modifications to the Hermes Agent source code in `~/.hermes/hermes-agent/`. Always check for uncommitted changes before running this command.
- **False MCP Server Test Failure**: Using `timeout 5 hermes mcp serve` to test MCP server functionality is incorrect: `hermes mcp serve` is a long-running process, so the timeout will always kill it prematurely, returning a false failure. Use background execution + log checking instead.

---

## Where to Find Things

| Looking for... | Location |
|----------------|----------|
| Config options | `hermes config edit` or [Configuration docs](https://hermes-agent.nousresearch.com/docs/user-guide/configuration) |
| Available tools | `hermes tools list` or [Tools reference](https://hermes-agent.nousresearch.com/docs/reference/tools-reference) |
| Slash commands | `/help` in session or [Slash commands reference](https://hermes-agent.nousresearch.com/docs/reference/slash-commands) |
| Skills catalog | `hermes skills browse` or [Skills catalog](https://hermes-agent.nousresearch.com/docs/reference/skills-catalog) |
| Provider setup | `hermes model` or [Providers guide](https://hermes-agent.nousresearch.com/docs/integrations/providers) |
| Platform setup | `hermes gateway setup` or [Messaging docs](https://hermes-agent.nousresearch.com/docs/user-guide/messaging/) |
| MCP servers | `hermes mcp list` or [MCP guide](https://hermes-agent.nousresearch.com/docs/user-guide/features/mcp) |
| Profiles | `hermes profile list` or [Profiles docs](https://hermes-agent.nousresearch.com/docs/user-guide/profiles) |
| Cron jobs | `hermes cron list` or [Cron docs](https://hermes-agent.nousresearch.com/docs/user-guide/features/cron) |
| Memory | `hermes memory status` or [Memory docs](https://hermes-agent.nousresearch.com/docs/user-guide/features/memory) |
| Env variables | `hermes config env-path` or [Env vars reference](https://hermes-agent.nousresearch.com/docs/reference/environment-variables) |
| CLI commands | `hermes --help` or [CLI reference](https://hermes-agent.nousresearch.com/docs/reference/cli-commands) |
| Gateway logs | `~/.hermes/logs/gateway.log` |
| Session files | `~/.hermes/sessions/` or `hermes sessions browse` |
| Source code | `~/.hermes/hermes-agent/` |

---

## Contributor Quick Reference

For occasional contributors and PR authors. Full developer docs: https://hermes-agent.nousresearch.com/docs/developer-guide/

### Project Layout

```
hermes-agent/
├── run_agent.py          # AIAgent — core conversation loop
├── model_tools.py        # Tool discovery and dispatch
├── toolsets.py           # Toolset definitions
├── cli.py                # Interactive CLI (HermesCLI)
├── hermes_state.py       # SQLite session store
├── agent/                # Prompt builder, context compression, memory, model routing, credential pooling, skill dispatch
├── hermes_cli/           # CLI subcommands, config, setup, commands
│   ├── commands.py       # Slash command registry (CommandDef)
│   ├── config.py         # DEFAULT_CONFIG, env var definitions
│   └── main.py           # CLI entry point and argparse
├── tools/                # One file per tool
│   └── registry.py       # Central tool registry
├── gateway/              # Messaging gateway
│   └── platforms/        # Platform adapters (telegram, discord, etc.)
├── cron/                 # Job scheduler
├── tests/                # ~3000 pytest tests
└── website/              # Docusaurus docs site
```

Config: `~/.hermes/config.yaml` (settings), `~/.hermes/.env` (API keys).

### Adding a Tool (3 files)

**1. Create `tools/your_tool.py`:**
```python
import json, os
from tools.registry import registry

def check_requirements() -> bool:
    return bool(os.getenv("EXAMPLE_API_KEY"))

def example_tool(param: str, task_id: str = None) -> str:
    return json.dumps({"success": True, "data": "..."})

registry.register(
    name="example_tool",
    toolset="example",
    schema={"name": "example_tool", "description": "...", "parameters": {...}},
    handler=lambda args, **kw: example_tool(
        param=args.get("param", ""), task_id=kw.get("task_id")),
    check_fn=check_requirements,
    requires_env=["EXAMPLE_API_KEY"],
)
```

**2. Add to `toolsets.py`** → `_HERMES_CORE_TOOLS` list.

Auto-discovery: any `tools/*.py` file with a top-level `registry.register()` call is imported automatically — no manual list needed.

All handlers must return JSON strings. Use `get_hermes_home()` for paths, never hardcode `~/.hermes`.

### Adding a Slash Command

1. Add `CommandDef` to `COMMAND_REGISTRY` in `hermes_cli/commands.py`
2. Add handler in `cli.py` → `process_command()`
3. (Optional) Add gateway handler in `gateway/run.py`

All consumers (help text, autocomplete, Telegram menu, Slack mapping) derive from the central registry automatically.

### Agent Loop (High Level)

```
run_conversation():
  1. Build system prompt
  2. Loop while iterations < max:
     a. Call LLM (OpenAI-format messages + tool schemas)
     b. If tool_calls → dispatch each via handle_function_call() → append results → continue
     c. If text response → return
  3. Context compression triggers automatically near token limit
```

### Testing

```bash
python -m pytest tests/ -o 'addopts=' -q   # Full suite
python -m pytest tests/tools/ -q            # Specific area
```

- Tests auto-redirect `HERMES_HOME` to temp dirs — never touch real `~/.hermes/`
- Run full suite before pushing any change
- Use `-o 'addopts='` to clear any baked-in pytest flags

### Commit Conventions

```
type: concise subject line

Optional body.
```

Types: `fix:`, `feat:`, `refactor:`, `docs:`, `chore:`

### Key Rules

- **Never break prompt caching** — don't change context, tools, or system prompt mid-conversation
- **Message role alternation** — never two assistant or two user messages in a row
- Use `get_hermes_home()` from `hermes_constants` for all paths (profile-safe)
- Config values go in `config.yaml`, secrets go in `.env`
- New tools need a `check_fn` so they only appear when requirements are met
