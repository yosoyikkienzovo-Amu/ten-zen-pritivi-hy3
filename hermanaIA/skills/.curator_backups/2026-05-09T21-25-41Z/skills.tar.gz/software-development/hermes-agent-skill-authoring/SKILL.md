---
name: hermes-agent-skill-authoring
description: "Author in-repo SKILL.md: frontmatter, validator, structure."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [skills, authoring, hermes-agent, conventions, skill-md]
    related_skills: [writing-plans, requesting-code-review]
---

# Authoring Hermes-Agent Skills (in-repo)

## Overview

There are two places a SKILL.md can live:

1. **User-local:** `~/.hermes/skills/<maybe-category>/<name>/SKILL.md` — personal, not shared. Created via `skill_manage(action='create')`.
2. **In-repo (this skill is about this case):** `/home/bb/hermes-agent/skills/<category>/<name>/SKILL.md` — committed, shipped with the package. Use `write_file` + `git add`. `skill_manage(action='create')` does NOT target this tree.

## When to Use

- User asks you to add a skill "in this branch / repo / commit"
- You're committing a reusable workflow that should ship with hermes-agent
- You're editing an existing skill under `/home/bb/hermes-agent/skills/` (use `patch` for small edits, `write_file` for rewrites; `skill_manage` still works for patch on in-repo skills, but not for `create`)

## Required Frontmatter

Source of truth: `tools/skill_manager_tool.py::_validate_frontmatter`. Hard requirements:

- Starts with `---` as the first bytes (no leading blank line).
- Closes with `\n---\n` before the body.
- Parses as a YAML mapping.
- `name` field present.
- `description` field present, ≤ **1024 chars** (`MAX_DESCRIPTION_LENGTH`).
- Non-empty body after the closing `---`.

Peer-matched shape used by every skill under `skills/software-development/`:

```yaml
---
name: my-skill-name               # lowercase, hyphens, ≤64 chars (MAX_NAME_LENGTH)
description: Use when <trigger>. <one-line behavior>.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [short, descriptive, tags]
    related_skills: [other-skill, another-skill]
---
```

`version` / `author` / `license` / `metadata` are NOT enforced by the validator, but every peer has them — omit and your skill sticks out.

## Size Limits

- Description: ≤ 1024 chars (enforced).
- Full SKILL.md: ≤ 100,000 chars (enforced as `MAX_SKILL_CONTENT_CHARS`, ~36k tokens).
- Peer skills in `software-development/` sit at **8-14k chars**. Aim for that range. If you're pushing past 20k, split into `references/*.md` and reference them from SKILL.md.

## Peer-Matched Structure

Every in-repo skill follows roughly:

```
# <Title>

## Overview
One or two paragraphs: what and why.

## When to Use
- Bulleted triggers
- "Don't use for:" counter-triggers

## <Topic sections specific to the skill>
- Quick-reference tables are common
- Code blocks with exact commands
- Hermes-specific recipes (tests via scripts/run_tests.sh, ui-tui paths, etc.)

## Common Pitfalls
Numbered list of mistakes and their fixes.

## Verification Checklist
- [ ] Checkbox list of post-action verifications

## One-Shot Recipes (optional)
Named scenarios → concrete command sequences.
```

Not every section is mandatory, but `Overview` + `When to Use` + actionable body + pitfalls are the minimum for the skill to feel like a peer.

## Writing Style

- Use clear, imperative steps
- Include exact commands when possible
- Add "Pitfalls" sections for common errors
- Keep it scannable with headers and bullets
- **SIEMPRE enumerar propuestas en formato numerado (1, 2, 3...)** según regla de Amú Ikki: "enumerar tus propuestas siempre". Las respuestas con múltiples acciones deben ser listas numeradas, no viñetas.

## Atomic Design & Architecture Discipline (Lecciones de Kumi)
- **Regla de Oro**: Una skill debe poder describirse en UNA oración. Si no, es una "caja de zapatos" y debe dividirse.
- **Ejemplo Correcto**: "sensor-disk-health: Mide espacio y escribe .state.json."
- **Ejemplo Incorrecto**: "autonomous-system-optimizer" (demasiado amplia).
- **Arquitectura de 3 Capas (SRP)**:
  1. **Sensor**: Mide y escribe estado (ej. `.state.json`). No decide.
  2. **Brain**: Lee estado y decide. No se auto-modifica sin score > 90 y validación externa.
  3. **Integrity**: Valida y hace rollback.
- **Fail-Safe**: Mejor error explícito que falla silencioso. Todo script debe tener `## Pitfalls` documentados.
- **Referencia**: Ver `references/kumi_lessons_atomic_design.md` en la skill `hermes-agent` para detalles completos.

## Skill Consolidation, Deduplication & Categorization (Reglas de Amú Ikki)
Cuando se requiera consolidar skills en `~/.hermes/skills/` (directorio oficial), seguir estrictamente este flujo:

### Prioridad de Categorización (orden de enumeración)
1. **Prioridad 1: Organización, reorganización, orden y ejecución** (ej. software-development, autonomous-ai-agents, devops, note-taking)
2. **Prioridad 2: Seguridad, registro y privacidad** (ej. red-teaming, Guardian-Genbu, mcp)
3. **Prioridad 3: Otras categorías** (ej. data-science, mlops, research, media)
4. **Prioridad 4: Diseño y marketing** (ej. creative, diagramming, gifs)

### Flujo de Consolidación
1. Enumerar todas las skills en el directorio oficial `~/.hermes/skills/` usando `ls -1` y clasificar por la prioridad anterior.
2. Enumerar skills en directorios no oficiales (ej. `~/Conciencia_TEN-ZEN_PRITivi_HY3/Skills/`) para detectar duplicados y skills únicas.
3. **Verificar duplicados por contenido**: No basarse solo en el nombre de la skill. Leer el SKILL.md completo de ambas versiones para confirmar si el contenido es idéntico o difiere.
4. Si el contenido es idéntico: Eliminar la versión no oficial, mantener la oficial.
5. Si el contenido difiere: Fusionar ambas versiones, conservando la información valiosa para ambos casos de uso.
6. Mover skills únicas de directorios no oficiales al directorio oficial `~/.hermes/skills/` respetando su categoría de prioridad.
7. **SIEMPRE enumerar propuestas y pasos en formato numerado** (1, 2, 3...) según regla crítica de Amú Ikki.

### Common Pitfalls
1. **No verificar contenido de duplicados**: Confiar solo en el nombre de la skill lleva a perder información valiosa si el contenido difiere.
2. **No respetar el orden de prioridad**: Las skills de organización deben aparecer primero en enumeraciones, seguidas de seguridad, otras, y diseño/marketing al final.
3. **Mantener duplicados en múltiples directorios**: Esto causa confusión y desincronización; centralizar siempre en el directorio oficial.

## Manejo de Tareas Pendientes (Archiveros de TEN-ZEN)

Al registrar tareas para Amú Ikki, usar la estructura oficial ubicada en:
`~/.hermes/hermes-agent/venv/Documentos Clave Hermes Prime/TAREas-Tenzen HY3 p r e v i e w/`

**Formato de archivo (.md):**
```markdown
# TAREA
## Fecha y Hora
[YYYY-MM-DD_HH-MM-SS + UTC-3 Argentina]
## Estado
[Pendiente/En Progreso/Concretada]
## Descripción
[Detalles del trabajo]
## Resultados
[Salida de comandos o estado final]
## Notas
[Alternativas, contexto y advertencias]
```

**Carpetas de destino:**
- `Inmediatas-lomasPRONTOposible/`: Tareas urgentes.
- `Mediano Plazo/`: Configuraciones y setups.
- `Largo Plazo/`: Proyectos evolutivos.
- `Criticas-Arreglos/`: Errores críticos del sistema.
- `Concretadas/`: Tareas finalizadas.

**Regla crítica (""Siempre preguntar, advertir y sugerir""):** Antes de ejecutar cambios en configuraciones del sistema (`.bashrc`, `config.yaml`) o en rutas protegidas de Windows (`system32`), SIEMPRE consultar, advertir y sugerir a Amú Ikki.

## Directory Placement

```
skills/<category>/<skill-name>/SKILL.md
```

Categories currently in repo (confirm with `ls skills/`): `autonomous-ai-agents`, `creative`, `data-science`, `devops`, `dogfood`, `email`, `gaming`, `github`, `leisure`, `mcp`, `media`, `mlops/*`, `note-taking`, `productivity`, `red-teaming`, `research`, `smart-home`, `social-media`, `software-development`.

Pick the closest existing category. Don't invent new top-level categories casually.

## Workflow

1. **Survey peers** in the target category:
   ```
   ls skills/<category>/
   ```
   Read 2-3 peer SKILL.md files to match tone and structure.
2. **Check validator constraints** in `tools/skill_manager_tool.py` if unsure.
3. **Draft** with `write_file` to `skills/<category>/<name>/SKILL.md`.
4. **Validate locally**:
   ```python
   import yaml, re, pathlib
   content = pathlib.Path("skills/<category>/<name>/SKILL.md").read_text()
   assert content.startswith("---")
   m = re.search(r'\n---\s*\n', content[3:])
   fm = yaml.safe_load(content[3:m.start()+3])
   assert "name" in fm and "description" in fm
   assert len(fm["description"]) <= 1024
   assert len(content) <= 100_000
   ```
5. **Git add + commit** on the active branch.
6. **Note:** the CURRENT session's skill loader is cached — `skill_view` / `skills_list` will not see the new skill until a new session. This is expected, not a bug.

## Cross-Referencing Other Skills

`metadata.hermes.related_skills` unions both trees (`skills/` in-repo and `~/.hermes/skills/`) at load time. You CAN reference a user-local skill from an in-repo skill, but it won't resolve for other users who clone the repo fresh. Prefer referencing only in-repo skills from in-repo skills. If a frequently-referenced skill lives only in `~/.hermes/skills/`, consider promoting it to the repo.

## Editing Existing In-Repo Skills

- **Small fix (typo, added pitfall, tightened trigger):** `skill_manage(action='patch', name=..., old_string=..., new_string=...)` works fine on in-repo skills.
- **Major rewrite:** `write_file` the whole SKILL.md. `skill_manage(action='edit')` also works but requires supplying the full new content.
- **Adding supporting files:** `write_file` to `skills/<category>/<name>/references/<file>.md`, `templates/<file>`, or `scripts/<file>`. `skill_manage(action='write_file')` also works and enforces the references/templates/scripts/assets subdir allowlist.
- **Always commit** the edit — in-repo skills are source, not runtime state.

## Common Pitfalls

1. **Using `skill_manage(action='create')` for an in-repo skill.** It writes to `~/.hermes/skills/`, not the repo tree. Use `write_file` for in-repo creation.

2. **Leading whitespace before `---`.** The validator checks `content.startswith("---")`; any leading blank line or BOM fails validation.

3. **Description too generic.** Peer descriptions start with "Use when ..." and describe the *trigger class*, not the one task. "Use when debugging X" > "Debug X".

4. **Forgetting the author/license/metadata block.** Not validator-enforced, but every peer has it; omitting makes the skill look half-finished.

5. **Writing a skill that duplicates a peer.** Before creating, `ls skills/<category>/` and open 2-3 peers. Prefer extending an existing skill to creating a narrow sibling.

6. **Expecting the current session to see the new skill.** It won't. The skill loader is initialized at session start. Verify in a fresh session or via `skill_view` using the exact path.

7. **Linking to skills that don't exist in-repo.** `related_skills: [some-user-local-skill]` works for you but breaks for other clones. Prefer only in-repo links.

## Verification Checklist

- [ ] File is at `skills/<category>/<name>/SKILL.md` (not in `~/.hermes/skills/`)
- [ ] Frontmatter starts at byte 0 with `---`, closes with `\n---\n`
- [ ] `name`, `description`, `version`, `author`, `license`, `metadata.hermes.{tags, related_skills}` all present
- [ ] Name ≤ 64 chars, lowercase + hyphens
- [ ] Description ≤ 1024 chars and starts with "Use when ..."
- [ ] Total file ≤ 100,000 chars (aim for 8-15k)
- [ ] Structure: `# Title` → `## Overview` → `## When to Use` → body → `## Common Pitfalls` → `## Verification Checklist`
- [ ] `related_skills` references resolve in-repo (or are explicitly OK to be user-local)
- [ ] `git add skills/<category>/<name>/ && git commit` completed on the intended branch
