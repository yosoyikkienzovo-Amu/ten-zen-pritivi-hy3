#!/bin/bash
# Corrected Telegram Hook Installation Script for Hermes Agent
# Includes fixes for YAML indentation, .env protection, and dependency handling
# Usage: chmod +x instalar_hooks_telegram.sh && ./instalar_hooks_telegram.sh

set -e

# --- CONFIGURATION (Replace with your actual values) ---
TELEGRAM_BOT_TOKEN="your_bot_token_from_botfather"
TELEGRAM_HOME_CHANNEL="your_chat_id_from_userinfobot"
OPENROUTER_API_KEY="your_openrouter_api_key"
# -----------------------------------------------------

echo "🔧 Installing Telegram hooks for Hermes Agent..."

# 1. Install required dependencies
echo "📦 Installing python-telegram-bot and httpx..."
source ~/.hermes/hermes-agent/.venv/bin/activate
pip install python-telegram-bot httpx --quiet

# 2. Enable linger for gateway background service
echo "⚙️ Enabling linger for gateway service..."
sudo loginctl enable-linger $USER

# 3. Configure environment variables (protected .env file, use terminal commands)
echo "🔑 Configuring environment variables..."
mkdir -p ~/.hermes
grep -q "TELEGRAM_BOT_TOKEN" ~/.hermes/.env 2>/dev/null || echo "TELEGRAM_BOT_TOKEN=${TELEGRAM_BOT_TOKEN}" >> ~/.hermes/.env
grep -q "TELEGRAM_HOME_CHANNEL" ~/.hermes/.env 2>/dev/null || echo "TELEGRAM_HOME_CHANNEL=${TELEGRAM_HOME_CHANNEL}" >> ~/.hermes/.env
grep -q "OPENROUTER_API_KEY" ~/.hermes/.env 2>/dev/null || echo "OPENROUTER_API_KEY=${OPENROUTER_API_KEY}" >> ~/.hermes/.env
grep -q "GATEWAY_ALLOW_ALL_USERS" ~/.hermes/.env 2>/dev/null || echo "GATEWAY_ALLOW_ALL_USERS=true" >> ~/.hermes/.env

# 4. Set Hermes config for OpenRouter provider and model
echo "⚙️ Configuring Hermes provider and model..."
hermes config set provider openrouter
hermes config set model tencent/hy3-preview:free
hermes config set openrouter_api_key "${OPENROUTER_API_KEY}"

# 5. Create long-task-alert hook (fixed YAML indentation)
echo "📦 Creating long-task-alert hook..."
mkdir -p ~/.hermes/hooks/long-task-alert
cat > ~/.hermes/hooks/long-task-alert/HOOK.yaml << 'EOF'
name: long-task-alert
description: Alert on Telegram when agent exceeds 10 steps
events:
  - agent:step
EOF

cat > ~/.hermes/hooks/long-task-alert/handler.py << 'EOF'
import os
import httpx

THRESHOLD = 10
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_HOME_CHANNEL")

async def handle(event_type: str, context: dict):
    iteration = context.get("iteration", 0)
    if iteration == THRESHOLD and BOT_TOKEN and CHAT_ID:
        tools = ", ".join(context.get("tool_names", []))
        text = f"⚠️ Agent at {iteration} steps. Tools used: {tools}"
        async with httpx.AsyncClient() as client:
            await client.post(
                f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                json={"chat_id": CHAT_ID, "text": text},
                timeout=5
            )
EOF

# 6. Create boot-md hook (fixed YAML indentation)
echo "📦 Creating boot-md hook..."
mkdir -p ~/.hermes/hooks/boot-md
cat > ~/.hermes/hooks/boot-md/HOOK.yaml << 'EOF'
name: boot-md
description: Execute BOOT.md checklist on gateway startup
events:
  - gateway:startup
EOF

cat > ~/.hermes/hooks/boot-md/handler.py << 'EOF'
import logging
import threading
from pathlib import Path

logger = logging.getLogger("hooks.boot-md")
BOOT_FILE = Path.home() / ".hermes" / "BOOT.md"

def _build_prompt(content: str) -> str:
    return (
        "You are an assistant executing a startup checklist. "
        "Follow instructions exactly. If nothing to report, respond only: [SILENT]\n\n---\n"
        f"{content}\n---"
    )

def _run_boot_agent(content: str) -> None:
    try:
        from gateway.run import _resolve_gateway_model, _resolve_runtime_agent_kwargs
        from run_agent import AIAgent
        agent = AIAgent(
            model=_resolve_gateway_model(),
            **_resolve_runtime_agent_kwargs(),
            platform="gateway",
            quiet_mode=True,
            skip_context_files=True,
            skip_memory=True,
            max_iterations=10,
        )
        result = agent.run_conversation(_build_prompt(content))
        response = result.get("final_response", "")
        if response and "[SILENT]" not in response:
            logger.info("boot-md completed: %s", response[:200])
        else:
            logger.info("boot-md completed (no updates)")
    except Exception as e:
        logger.error("boot-md failed: %s", e)

async def handle(event_type: str, context: dict) -> None:
    if not BOOT_FILE.exists():
        return
    content = BOOT_FILE.read_text(encoding="utf-8").strip()
    if not content:
        return
    logger.info("Running BOOT.md (%d characters)", len(content))
    thread = threading.Thread(target=_run_boot_agent, args=(content,), daemon=True)
    thread.start()
EOF

# 7. Create sample BOOT.md
echo "📝 Creating sample BOOT.md..."
cat > ~/.hermes/BOOT.md << 'EOF'
# Startup Checklist
1. Check for recent errors: `grep ERROR ~/.hermes/logs/gateway.log | tail -5`
2. If errors exist, send summary to Telegram (use TELEGRAM_HOME_CHANNEL variable)
3. If no issues, respond with [SILENT]
EOF

# 8. Restart gateway to load hooks
echo "🔄 Restarting Hermes gateway..."
hermes gateway restart

echo "✅ Telegram hooks installed successfully!"
echo "📌 Verify installation:"
echo "  1. Check Telegram connected: grep -i 'telegram connected' ~/.hermes/logs/gateway.log"
echo "  2. Check hooks loaded: tail -50 ~/.hermes/logs/gateway.log | grep -i hook"
echo "  3. Test alert by forcing agent to run >10 steps"
