# WSL to Windows LM Studio - Setup & Troubleshooting

## The Core Problem
WSL cannot reach Windows `localhost:1234` by default. LM Studio's "Permitir Conexiones de Red" must be ON, but that alone isn't enough.

## Verified Working Steps

### 1. Windows Firewall Rule (CRITICAL)
In **PowerShell as Administrator**:
```powershell
New-NetFirewallRule -DisplayName "WSL LM Studio" -Direction Inbound -LocalPort 1234 -Protocol TCP -Action Allow
```

### 2. Verify LM Studio is Listening on All Interfaces
In PowerShell:
```powershell
netstat -ano | findstr :1234
```
**Must show**: `0.0.0.0:1234` or `192.168.x.x:1234`
**NOT**: `127.0.0.1:1234` (means "Permitir Conexiones" didn't apply properly)

If `127.0.0.1`, restart LM Studio completely after toggling the setting.

### 3. Test Connectivity from WSL
```bash
# Try the resolv.conf nameserver IP
WIN_IP=$(cat /etc/resolv.conf | grep nameserver | awk '{print $2}')
curl -s --max-time 5 http://$WIN_IP:1234/v1/models

# Try WSL2 magic DNS
curl -s --max-time 5 http://host.docker.internal:1234/v1/models

# Try physical LAN IP (from LM Studio's "Reachable at")
curl -s --max-time 5 http://192.168.1.174:1234/v1/models
```

### 4. Configure Hermes config.yaml
Once connectivity works, edit `~/.hermes/config.yaml`:
```yaml
model:
  default: "mistralai/ministral-3b"
  provider: "custom"
  extra:
    api_base: "http://192.168.1.174:1234/v1"  # Use working IP from step 3
    api_key: ""

auxiliary:
  compression:
    provider: "custom"
    extra:
      api_base: "http://192.168.1.174:1234/v1"
      api_key: ""
  title_generation:
    provider: "custom"
    extra:
      api_base: "http://192.168.1.174:1234/v1"
      api_key: ""
```

### 5. Restart Gateway
```bash
sudo loginctl enable-linger $USER  # if not done already
hermes gateway restart
```

## Common Failures & Fixes

| Symptom | Cause | Fix |
|---------|-------|-----|
| `curl` times out | Firewall blocking WSL subnet | Add firewall rule (Step 1) |
| `127.0.0.1:1234` in netstat | LM Studio not listening externally | Toggle "Permitir Conexiones" → Restart LM Studio |
| `host.docker.internal` fails | WSL2 version too old | Update WSL: `wsl --update` |
| "No auxiliary LLM provider" error | `auxiliary:` section empty/missing | Configure as in Step 4 |

## Key Learnings
- Always backup config before editing: `cp ~/.hermes/config.yaml ~/.hermes/config.yaml.backup-$(date +%Y%m%d)`
- The `api_base` URL must end with `/v1` for LM Studio compatibility
- Model name must match exactly what LM Studio shows (e.g., `mistralai/ministral-3b`)
- Firewall rules in Windows are usually the missing piece
