# Hermes Agent & MCP Safe Upgrade Guide
Corrected workflow and script for upgrading `hermes-agent` and `mcp` packages, avoiding common pitfalls identified in session 2026-05-05 with Amú Ikki.

## Risks of Unchecked Upgrades
1. `--force-reinstall hermes-agent` overwrites local source modifications in `~/.hermes/hermes-agent/`
2. Latest `mcp` package may conflict with existing MCP servers (e.g., MemPalace)
3. Using `timeout 5 hermes mcp serve` returns false failures (long-running process killed prematurely)

## Corrected Upgrade Script
```bash
#!/bin/bash
VENV="/home/amu/.hermes/hermes-agent/.venv"
PIP="$VENV/bin/pip"
HERMES="$VENV/bin/hermes"
BACKUP_DIR="$HOME/hermes-backups/$(date +%Y%m%d_%H%M%S)"

echo "=== [1/5] Backup local changes ==="
mkdir -p "$BACKUP_DIR"
cp -r ~/.hermes/hermes-agent "$BACKUP_DIR/hermes-agent-src" 2>/dev/null
cp ~/.hermes/config.yaml "$BACKUP_DIR/config.yaml"

echo "=== [2/5] Check local git status ==="
cd ~/.hermes/hermes-agent && git status

echo "=== [3/5] Upgrade MCP package ==="
$PIP install --upgrade mcp

echo "=== [4/5] Test MCP server safely ==="
tmux new-session -d -s mcp-test "$HERMES mcp serve"
sleep 5
grep -i "mcp server started" ~/.hermes/logs/gateway.log && echo "✅ MCP server started successfully" || echo "❌ MCP server failed to start"
tmux kill-session -t mcp-test

echo "=== [5/5] Upgrade Hermes Agent (only if Step4 succeeded) ==="
$PIP install --upgrade --force-reinstall hermes-agent

echo "=== Verify ==="
$HERMES doctor
$HERMES mcp list
```

## Post-Upgrade Verification
- Run `hermes doctor` to check config and dependencies
- Run `hermes mcp list` to confirm MCP servers are still enabled
- Restart Hermes gateway if running: `hermes gateway restart`
