# Lecciones de Kamisama Kumi (2026-05-05)

## Principio de Skills Atómicas
- **Regla de Oro**: Si no puedes describir la skill en una oración, está mal diseñada.
- **Ejemplo Correcto**: "sensor-disk-health: Mide espacio libre y errores, escribe .state.json."
- **Ejemplo Incorrecto**: "autonomous-system-optimizer" (caja de zapatos con todo adentro).

## Arquitectura de 3 Capas (SRP)
Para sistemas autónomos, no acumular agentes sueltos. Usar:
1. **Sensor**: Mide y escribe estado (ej. `.state.json`). No decide.
2. **Brain**: Lee estado, decide y ejecuta. No se auto-modifica sin score > 90.
3. **Integrity**: Valida y hace rollback si falla.

## Lecciones de Disciplina Arquitectónica
- **Menos es más**: Un sistema autónomo no es una colección de scripts, es un organismo.
- **Fail-Safe > Fail-Operational**: Mejor detenerse gritando que fallar en silencio (ej. Get-Counter roto).
- **Cooldown**: Un agente sin freno es un martillo. Mantener frecuencias razonables (ej. 1h mín).

## Validación de Auto-Modificación
Un agente nunca debe modificar su propia frecuencia o código sin:
1. Score de confianza > 90 durante 48h.
2. Aprobación de un segundo agente (Brain) o del usuario (Ikki).
3. Backup del estado anterior y rollback automático.
