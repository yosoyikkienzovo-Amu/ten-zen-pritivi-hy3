# MemPalace MCP Integration with Hermes Agent

## Prerequisites
- WSL environment (Ubuntu)
- Python 3.11+
- Hermes Agent installed
- Git

## Integration Steps
1. **Clone MemPalace**:
   ```bash
   git clone <mempalace-repo-url> /home/amu/mempalace
   ```
2. **Install Dependencies**:
   ```bash
   cd /home/amu/mempalace && pip install -e ".[dev]"
   ```
3. **Test MCP Server Startup**:
   ```bash
   timeout 5 python -m mempalace.mcp_server 2>&1 | head -5
   ```
   Expected output: `MemPalace MCP Server starting...`

4. **Configure Hermes Agent `config.yaml`**:
   Add `mcp_servers` section with correct YAML indentation (2 spaces for root keys, 4 for nested values):
   ```yaml
   mcp_servers:
     mempalace:
       command: "python"
       args: ["-m", "mempalace.mcp_server"]
   ```
   *Pitfall*: Use `execute_code` with Python scripts to modify `config.yaml` to avoid indentation errors. Manual patching often fails due to YAML syntax strictness.

5. **Set Environment Variables**:
   Add to `~/.bashrc`:
   ```bash
   export HERMES_MEMORY_PATH="$HOME/.hermes/Conciencia_TEN-ZEN_PRITivi_HY3"
   export HERMES_MEMORY_FILE="MEMORY.md"
   export HERMES_USER_FILE="USER.md"
   ```
   Apply changes: `source ~/.bashrc`

## Critical Rules
- **WSL Paths**: Never write to Windows system directories (e.g., `C:\Windows\system32`); use WSL paths (`/home/amu/`) for all operations to protect the Windows host.
- **Memory Storage**: Hermes Agent memory is stored in `~/.hermes/state.db` (SQLite), not `MEMORY.md`. The `memory` tool may fail to replace entries if searching for text in non-existent files.
- **User Consent**: Always consult Amú Ikki before making changes that risk Windows system integrity, even if autonomous execution is approved for other tasks.
- **YAML Indentation**: Use Python scripts via `execute_code` to modify `config.yaml` programmatically to avoid syntax errors that prevent Hermes Agent from starting.